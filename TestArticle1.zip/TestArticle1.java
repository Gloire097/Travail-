package bac3ig;
import java.util.Scanner;
import java.util.Hashtable;
import java.util.Map;
public class TestArticle1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<String, String> stock = new Hashtable<String, String>();
		Scanner lect = new Scanner(System.in);
		stock.put("001", "cable");
		stock.put("002", "bonbon");
		stock.put("003", "biscuit");
		stock.put("004", "omo");
		stock.put("005", "pain");
		stock.put("006", "jus");
		stock.put("007", "coca");
		stock.put("008", "djino");
		stock.put("009", "WORLD COLA");
		stock.put("010", "bora");
		stock.put("011", "mentos");
		stock.put("012", "LAIT");
		stock.put("013", "sachet");
		stock.put("014", "sucre");
		stock.put("015", "sel");
		stock.put("016", "Lipton");
		stock.put("017", "chocolat");
		stock.put("018", "dasani");
		stock.put("019", "savana");
		stock.put("020", "fruticana");
		System.out.println(" tapez le code de l'article soit le nom de l'article que vous désirez : ");
		String rech = lect.next();
		for (Map.Entry mapentry : stock.entrySet()) {
			if (mapentry.getValue().equals(rech) || mapentry.getKey().equals(rech))
				System.out.println("cle : " + mapentry.getKey() + " | valeur : " + mapentry.getValue());
		}

	}

}
